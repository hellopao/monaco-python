import distutils.command.sdist
import distutils.config

d = distutils.config.PyPIRCCommand
c = distutils.command.sdist.sdist
